let respuestasCorrectas = {
  q1: "a",
  q2: "b",
  q3: "b"
};

let resultados = [];

function evaluar() {
  let form = document.forms["quizForm"];
  resultados = [];
  let totalCorrectas = 0;

  for (let i = 1; i <= 3; i++) {
    let pregunta = "q" + i;
    let respuesta = form[pregunta].value;
    let esCorrecta = respuesta === respuestasCorrectas[pregunta];
    resultados.push(esCorrecta ? 1 : 0);
    if (esCorrecta) totalCorrectas++;
  }

  document.getElementById("resultado").innerHTML = 
    `Obtuviste ${totalCorrectas} de 3 puntos.`;

  mostrarGrafica();
}

function mostrarGrafica() {
  let ctx = document.getElementById('grafica').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Pregunta 1', 'Pregunta 2', 'Pregunta 3'],
      datasets: [{
        label: 'Puntaje por pregunta',
        data: resultados,
        backgroundColor: ['#4caf50', '#2196f3', '#ff9800']
      }]
    },
    options: {
      scales: {
        y: { beginAtZero: true, max: 1 }
      }
    }
  });
}

function generarPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.text("Resultados del Diagnóstico HTML", 10, 10);
  resultados.forEach((punto, index) => {
    doc.text(`Pregunta ${index + 1}: ${punto === 1 ? "Correcta" : "Incorrecta"}`, 10, 20 + index * 10);
  });

  doc.save("diagnostico-html.pdf");
}
